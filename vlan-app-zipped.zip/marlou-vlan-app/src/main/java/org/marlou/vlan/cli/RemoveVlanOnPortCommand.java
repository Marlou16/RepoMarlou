package org.marlou.vlan.cli;

import java.net.URI;

import org.apache.karaf.shell.commands.Argument;
import org.apache.karaf.shell.commands.Command;
import org.marlou.vlan.VlanAwareDevice;
import org.marlou.vlan.VlanForwarder;
import org.onlab.packet.VlanId;
import org.onosproject.cli.AbstractShellCommand;
import org.onosproject.net.DeviceId;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.FlowRule;
import org.onosproject.net.flow.TrafficSelector;

@Command(scope = "onos", name = "remove-vlan-on-port",
description = "Given a device, removes an accepted vlan from a port")
public class RemoveVlanOnPortCommand extends AbstractShellCommand {

	@Argument(index=0, name="deviceId", required=true)
	URI deviceURI = null;
	
	@Argument(index=1, name="portId", required=true)
	int portId = 0;

	// For now, you can only add one accepted VLAN at once
	@Argument(index=2, name="vlanId", required=true)
	int vlanId = 0;
	
	@Override
	protected void execute() {
		// You should also check whether the values are valid, but for now I don't care.
		VlanForwarder forwarder = get(VlanForwarder.class);
		VlanAwareDevice concernedDevice = forwarder.devices().get(DeviceId.deviceId(deviceURI));

		/* Het eerste idee was via een HashMap de FloodingRule per VLAN op te slaan voor 'snelle' verwijdering
		 * Maar hoewel ik de equals door lijk te hebben, wordt die HashMap niet gevuld.
		 * Dus doen we de berekening maar hier en verwijderen we dan maar de FlowRule :)
		 * De oplossing hoeft toch nog niet 'schaalbaar' te zijn (want dat is denk ik het nadeel van deze oplossing)
		 */
		
		// Bouw een VLANID criterium voor de vergelijking daarna.
		TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
    	selectorBuilder.matchVlanId(VlanId.vlanId(((Integer) vlanId).shortValue())); 
    	TrafficSelector selector = selectorBuilder.build();
		
		for(FlowRule rule : forwarder.flowRuleService.getFlowEntriesById(forwarder.appId()))
		{
			if(rule.selector().criteria().equals(selector.criteria())) {
				forwarder.flowRuleService.removeFlowRules(rule);
				break;													// though I doubt whether this lets me leave the forEach [test with print statement?]
			}
		}
		
		// Update this shit, but check that you do nothing if the VLAN entry gets empty, then you should not add a rule.
		concernedDevice.removeVlanOnPort(vlanId, portId);
		
		if (concernedDevice.getPortsPerVlan().get(vlanId).isEmpty()) {
			concernedDevice.getPortsPerVlan().remove(vlanId);				// doing some cleaning
		}
		else {
			if (!forwarder.isReactiveMode()) {
				forwarder.installVlanFloodRule(concernedDevice, vlanId);	// install a new rule if in static mode!				
			}
		}
		
		// FUTURE WORK, UPDATE THE VLAN FLOODING GROUPS WHEN REMOVING A VLAN ON A PORT
		
	}

}
